<?php
/**
 * WebytePay - Gateway de Pagamento para o Vendi Aqui
 * Copyright (c) 2024 Webyte Desenvolvimentos. Todos os direitos reservados.
 *
 * Website: https://webytebr.com
 * Autor: Júnior Alves | https://webytebr.com
 *
 * LICENÇA
 * -------
 * Este software é fornecido sob licença e pode ser usado e copiado
 * apenas mediante o pagamento da taxa de licença.
 *
 * Proibida a redistribuição ou modificação sem a autorização expressa
 * da Webyte Desenvolvimentos. Qualquer uso não autorizado é estritamente 
 * proibido e poderá resultar em ações legais.
 */

 use App\Http\Controllers\WebytePayController;
 use Illuminate\Support\Facades\Route;

// Agrupar rotas do WebytePay
Route::prefix('webytepay')->middleware('auth')->group(function () {
    // Rota para criar transação
    Route::post('/transaction', [WebytePayController::class, 'createTransaction']);
    
    // Rota para listar transações do usuário
    Route::get('/transactions', [WebytePayController::class, 'getUserTransactions']);
    
    // Rota para webhook (caso necessário)
    // Route::post('/webhook', [WebytePayController::class, 'handleWebhook']);
});

 
